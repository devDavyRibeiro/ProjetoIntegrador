export enum NoticiaErrorStatus{
    None = "none",
  invalidName = "invalid-name",
  invalidControl = "invalid-control",
  invalidTag = 'invalid-tag',
  nullTag= 'null-tag',
  invalidFonte = 'invalid-fonte',
  nullFonte = 'null-fonte'
}