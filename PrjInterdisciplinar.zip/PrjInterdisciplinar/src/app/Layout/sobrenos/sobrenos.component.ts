import { Component } from '@angular/core';

@Component({
  selector: 'app-sobrenos',
  standalone: true,
  imports: [],
  templateUrl: './sobrenos.component.html',
  styleUrl: './sobrenos.component.css'
})
export class SobrenosComponent {

}
