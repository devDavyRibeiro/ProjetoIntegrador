import { MenuAdmin } from './menu-admin';

describe('MenuAdmin', () => {
  it('should create an instance', () => {
    expect(new MenuAdmin()).toBeTruthy();
  });
});
