import { Detalhe } from './detalhe';

describe('Detalhe', () => {
  it('should create an instance', () => {
    expect(new Detalhe()).toBeTruthy();
  });
});
