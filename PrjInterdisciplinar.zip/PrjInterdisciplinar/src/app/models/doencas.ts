export class Doencas {
  id: number = 0;
  title: String = "";
  description: String = "";
  image: String = "";
}
