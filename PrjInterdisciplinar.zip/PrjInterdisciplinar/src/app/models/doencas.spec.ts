import { Doencas } from './doencas';

describe('Doencas', () => {
  it('should create an instance', () => {
    expect(new Doencas()).toBeTruthy();
  });
});
