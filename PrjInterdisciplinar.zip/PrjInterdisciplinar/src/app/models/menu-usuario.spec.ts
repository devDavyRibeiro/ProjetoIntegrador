import { MenuUsuario } from './menu-usuario';

describe('MenuUsuario', () => {
  it('should create an instance', () => {
    expect(new MenuUsuario()).toBeTruthy();
  });
});
