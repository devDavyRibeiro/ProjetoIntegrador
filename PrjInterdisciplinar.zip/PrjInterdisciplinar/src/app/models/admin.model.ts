export interface IAdmin{
    id : number,
    userId : number,
    nivel : number,
}