export interface INoticia{
    id : number;
    titulo : string;
    descricao : string;
    tags_noticia : string[];
    fontes_noticia : string[];
    imagens_noticia : string[];
}