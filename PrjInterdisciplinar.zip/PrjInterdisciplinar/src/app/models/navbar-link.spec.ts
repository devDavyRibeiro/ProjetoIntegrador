import { NavbarLink } from './navbar-link';

describe('NavbarLink', () => {
  it('should create an instance', () => {
    expect(new NavbarLink()).toBeTruthy();
  });
});
