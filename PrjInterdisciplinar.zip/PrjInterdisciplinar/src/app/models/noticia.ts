export class Noticia {

  id: number = 0;
  title: string = '';
  tags: string = '';
  description: String = '';
  image: String = '';
}
