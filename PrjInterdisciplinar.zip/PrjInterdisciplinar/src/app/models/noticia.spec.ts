import { Noticia } from './noticia';

describe('Noticia', () => {
  it('should create an instance', () => {
    expect(new Noticia()).toBeTruthy();
  });
});
