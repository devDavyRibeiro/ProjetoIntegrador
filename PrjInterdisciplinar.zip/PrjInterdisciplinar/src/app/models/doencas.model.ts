export interface IDoenca{
  id : number,
  nome_doenca :  string,
  descricao : string,
  transmissao : string,
  tratamento : string,
  sintomas : string[],
  fontes_doenca : string[],
  imagens_doenca : string[],
}
