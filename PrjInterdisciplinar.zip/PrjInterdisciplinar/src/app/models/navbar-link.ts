export class NavbarLink {
    path: string = '';
    img: string = '';
    alt: string = '';
    nome: string = '';
}
