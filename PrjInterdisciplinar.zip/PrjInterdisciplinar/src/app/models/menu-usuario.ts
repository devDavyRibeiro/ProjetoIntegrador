export class MenuUsuario {
    path : string = '';
    nome : string = '';
    titulo : string = '';
    info : string = '';
    src : string = '';
}
