export interface Tag{
  id: number,
  nomeTag: string
}
