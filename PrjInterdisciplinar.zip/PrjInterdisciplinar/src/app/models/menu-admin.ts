export class MenuAdmin {
  path : string = '';
  nome : string = '';
  img : string = '';
}
