import { Reclamacao } from './reclamacao';

describe('Reclamacao', () => {
  it('should create an instance', () => {
    expect(new Reclamacao()).toBeTruthy();
  });
});
